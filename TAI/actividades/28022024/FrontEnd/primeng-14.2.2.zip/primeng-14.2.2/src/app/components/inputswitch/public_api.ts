export * from './inputswitch';
