export enum ConfirmEventType {
    ACCEPT,
    REJECT,
    CANCEL
}
