export * from './slidemenu';
