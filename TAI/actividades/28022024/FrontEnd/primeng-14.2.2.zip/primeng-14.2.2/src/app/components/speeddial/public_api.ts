export * from './speeddial';
