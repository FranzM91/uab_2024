export class FilterOperator {
    public static readonly AND = 'and';
    public static readonly OR = 'or';
}
