export interface SortMeta {
    field: string;
    order: number;
}
